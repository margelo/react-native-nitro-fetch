/**
 * Platform identifier for the exception
 */
export type ExceptionPlatform = 'android_platform' | 'ios_platform';
/**
 * Error type combining both Android and iOS error types.
 */
export type ErrorType = 'network' | 'quic' | 'callback' | 'security' | 'cronet' | 'inlineExecution' | 'urlSession' | 'other';
/**
 * Unified request exception that works across both platforms.
 * Contains all possible fields from both Android and iOS exceptions.
 * Platform-specific fields will be undefined on the other platform.
 */
export interface RequestException {
    readonly platform: ExceptionPlatform;
    readonly message: string;
    readonly code: number;
    readonly errorType: ErrorType;
    readonly internalErrorCode?: number;
    readonly networkErrorCode?: number;
    readonly quicErrorCode?: number;
    readonly stackTrace?: string;
    readonly errorDomain?: number;
    readonly localizedDescription?: string;
    readonly underlyingError?: string;
    readonly failingURL?: string;
    readonly causeMessage?: string;
}
//# sourceMappingURL=NitroException.d.ts.map