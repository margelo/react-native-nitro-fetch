import 'web-streams-polyfill/polyfill';
export declare class TextDecoder {
    readonly encoding: string;
    readonly fatal: boolean;
    readonly ignoreBOM: boolean;
    private readonly _decode;
    constructor(label?: string, options?: TextDecoderOptions);
    decode(input?: ArrayBuffer | ArrayBufferView, options?: TextDecodeOptions): string;
}
//# sourceMappingURL=TextDecoder.d.ts.map