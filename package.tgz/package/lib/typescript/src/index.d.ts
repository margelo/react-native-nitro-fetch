import 'web-streams-polyfill/polyfill';
import { TextDecoder } from './TextDecoder';
export { TextDecoder };
export { fetch, prefetch, prefetchOnAppStart, removeFromAutoPrefetch, clearAutoPrefetchQueue, fetchOnWorklet, } from './fetch';
export type { FetchOptions, FetchResponse, PrefetchOptions, WorkletMapper, } from './fetch';
//# sourceMappingURL=index.d.ts.map