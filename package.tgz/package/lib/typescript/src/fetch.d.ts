import type { NitroCronet as NitroCronetType, UrlResponseInfo } from './NitroCronet.nitro';
export declare class AbortError extends Error {
    constructor(message?: string);
}
export declare const NitroCronet: NitroCronetType;
export interface FetchOptions {
    method?: string;
    headers?: Record<string, string>;
    body?: ArrayBuffer | Uint8Array | string;
    cache?: 'default' | 'no-cache';
    signal?: AbortSignal;
}
export interface PrefetchOptions {
    url: string;
    method?: string;
    headers?: Record<string, string>;
    body?: ArrayBuffer | string;
    prefetchKey: string;
    maxAge?: number;
}
export declare class FetchResponse {
    private _info;
    private _stream;
    private _streamUsed;
    constructor(info: UrlResponseInfo, stream: ReadableStream<Uint8Array>);
    get headers(): Headers;
    get ok(): boolean;
    get status(): number;
    get statusText(): string;
    get url(): string;
    get redirected(): boolean;
    readonly type = "default";
    get bodyUsed(): boolean;
    get body(): ReadableStream<Uint8Array> | null;
    private _consumeStream;
    json(): Promise<any>;
    text(): Promise<string>;
    bytes(): Promise<Uint8Array>;
    arrayBuffer(): Promise<ArrayBuffer>;
    blob(): Promise<Blob>;
    formData(): Promise<FormData>;
    clone(): FetchResponse;
    toString(): string;
    toJSON(): object;
    get info(): UrlResponseInfo;
    get data(): Uint8Array;
}
export declare function prefetch(options: PrefetchOptions): Promise<void>;
export declare function prefetchOnAppStart(options: PrefetchOptions): Promise<void>;
export declare function removeFromAutoPrefetch(prefetchKey: string): Promise<void>;
export declare function clearAutoPrefetchQueue(): Promise<void>;
export type WorkletMapper<T> = (response: FetchResponse) => T | Promise<T>;
export declare function fetchOnWorklet<T>(url: string, options: FetchOptions | undefined, mapWorklet: WorkletMapper<T>, runtimeOptions?: {
    runtimeName?: string;
}): Promise<T>;
export declare function fetch(url: string, options?: FetchOptions): Promise<FetchResponse>;
//# sourceMappingURL=fetch.d.ts.map